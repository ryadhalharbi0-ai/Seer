
import 'package:flutter/material.dart';

class OffersPage extends StatelessWidget {
  final List<String> offers = [
    'خصم 25% في منتجع السودة',
    'دخول مجاني لمتحف رجال ألمع يوم الجمعة',
    'عشاء مجاني عند حجز ليلتين في فندق عسير بلازا',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('العروض')),
      body: ListView.builder(
        itemCount: offers.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.local_offer, color: Colors.red),
            title: Text(offers[index]),
          );
        },
      ),
    );
  }
}
