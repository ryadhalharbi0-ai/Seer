
import 'package:flutter/material.dart';

class TouristPlacesPage extends StatelessWidget {
  final List<Map<String, String>> places = [
    {
      'name': 'جبل السودة',
      'image': 'https://example.com/soudah.jpg',
      'desc': 'أحد أعلى القمم في المملكة ومنطقة جذب سياحي ممتازة.'
    },
    {
      'name': 'قرية رجال ألمع',
      'image': 'https://example.com/rajal.jpg',
      'desc': 'قرية تراثية رائعة فيها مباني قديمة ومتاحف.'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الأماكن السياحية')),
      body: ListView.builder(
        itemCount: places.length,
        itemBuilder: (context, index) {
          final place = places[index];
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              leading: Image.network(place['image']!, width: 70, fit: BoxFit.cover),
              title: Text(place['name']!),
              subtitle: Text(place['desc']!),
            ),
          );
        },
      ),
    );
  }
}
