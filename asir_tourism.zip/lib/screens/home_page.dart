
import 'package:flutter/material.dart';
import 'tourist_places_page.dart';
import 'offers_page.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('عسير سياحة')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: Text('الأماكن السياحية'),
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (context) => TouristPlacesPage()));
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text('العروض'),
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (context) => OffersPage()));
              },
            ),
          ],
        ),
      ),
    );
  }
}
