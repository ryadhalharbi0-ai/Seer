
import 'package:flutter/material.dart';
import 'screens/home_page.dart';

void main() {
  runApp(AsirTourismApp());
}

class AsirTourismApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'عسير سياحة',
      theme: ThemeData(primarySwatch: Colors.green),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}
